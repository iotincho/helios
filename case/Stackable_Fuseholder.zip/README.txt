                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1787609
Stackable Fuseholder by sk8rjess is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I DID NOT MAKE THIS!! I like to keep things I'm printing in one location, i'm simply uploading this from another site. The creator is Erik Cederberg(https://www.youmagine.com/meduza), he gets 100% of the credit!
Taken from original page:

A stackable fuseholder for automotive blade fuses that uses nothing more than 3D printed parts, M3 screws and regular blade connectors

I thought that most fuse holders were way too bulky for a project of mine, so i made these instead :) Print one endpiece, one startpice and as many middle pieces you want to stack for your project.
Materials and methods

For the total: 
- 2 pcs M3 Screws of a length that suites your stack 
- 2 pcs M3 Nuts
For each holder: 
- 2 6.3mm blade connectors 
- 2 pcs of cable, i used 1,5mm^2